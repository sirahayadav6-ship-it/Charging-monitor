package com.chargeflow.app

import android.app.Activity
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController

class ChargingActivity : Activity() {

    private var demo = false

    private val closer = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (!demo) finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        demo = intent.getBooleanExtra("demo", false)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        getSystemService(NotificationManager::class.java).cancel(ChargingService.ALERT_ID)

        val panel = ChargePanel(this, demo)
        panel.setOnClickListener { finish() }
        setContentView(panel)
        try { hideBars() } catch (_: Throwable) {}

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(closer, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(closer, f)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        getSystemService(NotificationManager::class.java).cancel(ChargingService.ALERT_ID)
    }

    override fun onDestroy() {
        try { unregisterReceiver(closer) } catch (_: Exception) {}
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
    }
}
