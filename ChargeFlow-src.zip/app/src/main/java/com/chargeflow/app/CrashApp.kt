package com.chargeflow.app

import android.app.Application
import java.io.File

/** Crash hone par error file me save karta hai, taaki app me dikha sakein. */
class CrashApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                File(filesDir, "crash.txt").writeText(e.stackTraceToString().take(3500))
            } catch (_: Throwable) {
            }
            old?.uncaughtException(t, e)
        }
    }
}
