package com.chargeflow.app

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.max

data class Reading(
    val pct: Float,
    val watts: Double,
    val volts: Double,
    val remainMs: Long,
    val charging: Boolean,
    val full: Boolean,
    val source: String
)

/**
 * Battery data: decimal %, watt, time-to-full.
 * Decimal % battery ke charge counter (µAh) se nikalta hai.
 */
object BatteryMonitor {
    private var emaUa = 0.0
    private val window = ArrayDeque<Pair<Long, Double>>()
    private var lastLevel = -1
    private var lastTick = 0L
    private var stepCounter = 0.0
    private var haveStep = false
    private var calLevel = -1
    private var calCounter = 0.0
    private var fullCap = 0.0
    private var loaded = false
    private var shown = 0f

    private fun reset() {
        emaUa = 0.0
        window.clear()
        lastLevel = -1
        lastTick = 0L
        haveStep = false
        calLevel = -1
    }

    fun read(ctx: Context): Reading {
        val prefs = ctx.getSharedPreferences("cf", Context.MODE_PRIVATE)
        if (!loaded) {
            fullCap = prefs.getLong("fullcap", 0L).toDouble()
            loaded = true
        }
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val st = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = st?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scale = st?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val lvl = if (scale > 0) level * 100 / scale else level
        val mv = st?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val plugged = st?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val status = st?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = plugged != 0
        val full = charging && (status == BatteryManager.BATTERY_STATUS_FULL || lvl >= 100)
        val volts = mv / 1000.0
        val now = SystemClock.elapsedRealtime()

        if (!charging) {
            reset()
            return Reading(lvl.toFloat(), 0.0, volts, -1L, false, false, "")
        }

        // ---- Current (tez response ke liye halka smoothing) ----
        val raw = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        var ua = if (raw == Long.MIN_VALUE || raw == Int.MIN_VALUE.toLong()) 0.0 else abs(raw).toDouble()
        if (ua in 1.0..20000.0) ua *= 1000.0 // kuch phones mA me dete hain
        emaUa = if (emaUa == 0.0) ua else emaUa * 0.4 + ua * 0.6

        // ---- Decimal percent from charge counter ----
        val counter = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER).toDouble()
        val counterOk = counter > 0
        var pct = lvl.toFloat()
        var cap = 0.0

        if (counterOk) {
            window.addLast(Pair(now, counter))
            while (window.size > 1 && now - window.first().first > 90_000) window.removeFirst()

            val consecutive = lastTick != 0L && now - lastTick < 5_000
            if (lastLevel != -1 && lvl == lastLevel + 1 && consecutive) {
                // level abhi-abhi +1 hua: yahan counter ek exact point hai
                stepCounter = counter
                haveStep = true
                if (calLevel == -1) {
                    calLevel = lvl
                    calCounter = counter
                } else if (lvl - calLevel >= 3) {
                    val est = (counter - calCounter) * 100.0 / (lvl - calLevel)
                    if (est in 1_000_000.0..40_000_000.0) {
                        fullCap = if (fullCap == 0.0) est else fullCap * 0.7 + est * 0.3
                        prefs.edit().putLong("fullcap", fullCap.toLong()).apply()
                    }
                    calLevel = lvl
                    calCounter = counter
                }
            } else if (lastLevel != -1 && lvl != lastLevel) {
                haveStep = false
                calLevel = -1
            }

            cap = if (fullCap > 0) fullCap else if (lvl > 0) counter / (lvl / 100.0) else 0.0
            if (fullCap > 0) {
                pct = (counter / fullCap * 100.0).toFloat().coerceIn(lvl - 0.5f, lvl + 1.0f)
            } else if (haveStep && cap > 0) {
                val frac = ((counter - stepCounter) / (cap / 100.0)).coerceIn(0.0, 0.99)
                pct = (lvl + frac).toFloat()
            }
        }
        pct = pct.coerceIn(0f, 100f)
        if (lastLevel == -1 || lvl < lastLevel || lvl > lastLevel + 1) shown = pct
        else if (pct < shown) pct = shown
        shown = pct

        // ---- Time to full ----
        // Speed: pehle counter se (µAh/hour = µA), warna current_now se
        var rateUa = 0.0
        if (counterOk && window.size >= 2) {
            val a = window.first()
            val b = window.last()
            val dt = b.first - a.first
            val d = b.second - a.second
            if (dt >= 15_000 && d > 0) rateUa = d / (dt / 3_600_000.0)
        }
        var remain = -1L
        val speed = if (rateUa > 0) rateUa else emaUa
        if (counterOk && cap > 0 && speed > 50_000) {
            val knee = cap * 0.8 // 80% ke baad charging slow hoti hai
            val hours = if (counter < knee) {
                (knee - counter) / speed + (cap - knee) / (speed * 0.45)
            } else {
                (cap - counter) / (speed * 0.75)
            }
            if (hours > 0) remain = (hours * 3_600_000).toLong()
        }
        if (remain <= 0 && Build.VERSION.SDK_INT >= 28) remain = bm.computeChargeTimeRemaining()

        // ---- Watt ----
        val mult = prefs.getFloat("wmul", 1f).toDouble()
        val watts = emaUa / 1e6 * volts * mult

        lastLevel = lvl
        lastTick = now

        val src = when (plugged) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
            else -> "Dock"
        }
        return Reading(pct, watts, volts, remain, true, full, src)
    }
}
