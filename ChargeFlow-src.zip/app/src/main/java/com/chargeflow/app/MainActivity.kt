package com.chargeflow.app

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var crashBox: LinearLayout
    private lateinit var crashText: TextView
    private lateinit var wBtn: Button
    private lateinit var hBtn: Button
    private val wSteps = floatArrayOf(1f, 1.5f, 2f)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = dp(20)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(label("⚡ ChargeFlow", 28f, Color.WHITE))
        root.addView(label("Charger lagao → lock screen pe animation, watt aur full hone ka time.", 14f, Color.LTGRAY))

        // Crash log box (sirf tab dikhega jab pichli baar app crash hua ho)
        crashBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#3A1010"))
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        crashBox.addView(label("⚠️ Pichli baar crash hua:", 15f, Color.parseColor("#FF8A80")))
        crashText = label("", 11f, Color.WHITE).apply { setTextIsSelectable(true) }
        crashBox.addView(crashText)
        crashBox.addView(button("Copy crash log") { copyCrash() })
        crashBox.addView(button("Clear") { File(filesDir, "crash.txt").delete(); refresh() })
        root.addView(crashBox)

        status = label("", 15f, Color.parseColor("#00E5A0")).apply { setPadding(0, pad, 0, pad) }
        root.addView(status)
        root.addView(button("1. Notification permission") { askNotif() })
        root.addView(button("2. Display over other apps (ON karo)") { overlay() })
        root.addView(button("3. Battery optimization OFF") { battery() })
        root.addView(button("4. Full-screen notification (Android 14)") { fullScreen() })
        root.addView(button("5. Service start karo") { startSvc(); refreshLater() })
        wBtn = button("") { cycleWatt() }
        hBtn = button("") { toggleHome() }
        root.addView(wBtn)
        root.addView(hBtn)
        root.addView(button("▶ Test animation") {
            startActivity(Intent(this, ChargingActivity::class.java).putExtra("demo", true))
        })
        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0B0F14"))
            isFillViewport = true
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        startSvc()
        refresh()
        refreshLater()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        refresh()
    }

    private fun refreshLater() {
        Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 1200)
    }

    private fun refresh() {
        val notif = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val over = Settings.canDrawOverlays(this)
        val bat = getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        val last = getSharedPreferences("cf", MODE_PRIVATE).getString("last", "abhi tak koi nahi")
        val cap = getSharedPreferences("cf", MODE_PRIVATE).getLong("fullcap", 0L)
        val calText = if (cap > 0) "Battery calibration: ${cap / 1000} mAh ✅" else "Battery calibration: abhi nahi (charge pe 3-4% badhne do)"
        updateButtons()
        status.text = "${tick(ChargingService.running)} Service chal rahi hai\n" +
            "${tick(notif)} Notification\n" +
            "${tick(over)} Display over other apps\n" +
            "${tick(bat)} Battery optimization off\n\n" +
            "Last charger event:\n$last\n\n$calText"

        val f = File(filesDir, "crash.txt")
        if (f.exists()) {
            crashText.text = f.readText()
            crashBox.visibility = android.view.View.VISIBLE
        } else {
            crashBox.visibility = android.view.View.GONE
        }
    }

    private fun copyCrash() {
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("crash", crashText.text))
        Toast.makeText(this, "Copy ho gaya", Toast.LENGTH_SHORT).show()
    }

    private fun cycleWatt() {
        val p = getSharedPreferences("cf", MODE_PRIVATE)
        val cur = p.getFloat("wmul", 1f)
        val i = wSteps.indexOfFirst { it == cur }
        p.edit().putFloat("wmul", wSteps[(i + 1) % wSteps.size]).apply()
        updateButtons()
    }

    private fun toggleHome() {
        val p = getSharedPreferences("cf", MODE_PRIVATE)
        p.edit().putBoolean("home", !p.getBoolean("home", true)).apply()
        updateButtons()
    }

    private fun updateButtons() {
        val p = getSharedPreferences("cf", MODE_PRIVATE)
        wBtn.text = "Watt correction: x${p.getFloat("wmul", 1f)}  (tap = badlo)"
        hBtn.text = "Home screen pe bhi dikhao: " + if (p.getBoolean("home", true)) "ON" else "OFF"
    }

    private fun tick(b: Boolean) = if (b) "✅" else "❌"

    private fun startSvc() {
        try { startForegroundService(Intent(this, ChargingService::class.java)) } catch (_: Exception) {}
    }

    private fun askNotif() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    private fun overlay() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun battery() {
        startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
    }

    private fun fullScreen() {
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                Toast.makeText(this, "Is phone me ye setting nahi hai", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Is Android version me zaroorat nahi", Toast.LENGTH_SHORT).show()
        }
    }

    private fun label(t: String, size: Float, color: Int) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
