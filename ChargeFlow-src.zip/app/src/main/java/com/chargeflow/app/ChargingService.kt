package com.chargeflow.app

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.ViewGroup
import android.view.WindowManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Foreground service:
 *  - charger lagte hi: lock screen / screen off pe ChargingActivity, home screen pe overlay (8 sec)
 *  - charging ke dauran screen ON hone par (lock screen pe) dobara dikhata hai
 */
class ChargingService : Service() {

    companion object {
        const val CH_SERVICE = "cf_service"
        const val CH_ALERT = "cf_alert"
        const val SERVICE_ID = 1
        const val ALERT_ID = 2

        @Volatile
        var running = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private var overlay: ChargePanel? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            try {
                when (intent.action) {
                    Intent.ACTION_POWER_CONNECTED -> trigger("Charger laga")
                    Intent.ACTION_POWER_DISCONNECTED -> hideOverlay()
                    Intent.ACTION_SCREEN_OFF -> hideOverlay()
                    Intent.ACTION_SCREEN_ON -> {
                        val km = getSystemService(KeyguardManager::class.java)
                        if (isCharging() && km.isKeyguardLocked) launchLockScreen("Screen on")
                    }
                }
            } catch (e: Throwable) {
                note("Error: ${e.javaClass.simpleName} ${e.message}")
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_SERVICE, "Charging monitor", NotificationManager.IMPORTANCE_MIN)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "Charging screen", NotificationManager.IMPORTANCE_HIGH)
        )

        val n = Notification.Builder(this, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_bolt)
            .setContentTitle("ChargeFlow chal raha hai")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(SERVICE_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(SERVICE_ID, n)
        }

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, f)
        }
        running = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        running = false
        hideOverlay()
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun note(msg: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        getSharedPreferences("cf", MODE_PRIVATE).edit().putString("last", "$time  $msg").apply()
    }

    private fun isCharging(): Boolean {
        val st = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (st?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
    }

    /** Charger lagne par: lock screen/screen off -> activity, warna (home screen) -> overlay */
    private fun trigger(reason: String) {
        val km = getSystemService(KeyguardManager::class.java)
        val pm = getSystemService(android.os.PowerManager::class.java)
        val locked = km.isKeyguardLocked || !pm.isInteractive
        if (locked) {
            launchLockScreen(reason)
        } else if (getSharedPreferences("cf", MODE_PRIVATE).getBoolean("home", true)) {
            showOverlay(reason)
        } else {
            note("$reason (screen unlocked, home screen option OFF)")
        }
    }

    private fun launchLockScreen(reason: String) {
        val intent = Intent(this, ChargingActivity::class.java).addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP
        )
        val pi = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CH_ALERT)
            .setSmallIcon(R.drawable.ic_bolt)
            .setContentTitle("Charging")
            .setFullScreenIntent(pi, true)
            .setAutoCancel(true)
            .setTimeoutAfter(5000)
            .build()
        getSystemService(NotificationManager::class.java).notify(ALERT_ID, n)

        try {
            startActivity(intent)
            note("$reason (lock screen) -> activity launch try ki")
        } catch (e: Throwable) {
            note("$reason (lock screen) -> launch fail: ${e.javaClass.simpleName}")
        }
    }

    private fun showOverlay(reason: String) {
        if (!Settings.canDrawOverlays(this)) {
            note("$reason (home screen) -> 'Display over other apps' permission nahi hai")
            return
        }
        hideOverlay()
        val wm = getSystemService(WindowManager::class.java)
        val panel = ChargePanel(this)
        panel.setOnClickListener { hideOverlay() }
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(panel, lp)
        overlay = panel
        handler.postDelayed({ hideOverlay() }, 8000)
        note("$reason (home screen) -> overlay dikhaya")
    }

    private fun hideOverlay() {
        handler.removeCallbacksAndMessages(null)
        val p = overlay ?: return
        overlay = null
        try { getSystemService(WindowManager::class.java).removeView(p) } catch (_: Exception) {}
    }
}
