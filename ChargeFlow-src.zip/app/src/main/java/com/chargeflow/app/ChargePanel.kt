package com.chargeflow.app

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.sin

/** Charging screen ka pura UI (animation + % + watt + time). Activity aur overlay dono use karte hain. */
class ChargePanel(context: Context, private val demo: Boolean = false) : LinearLayout(context) {

    private val chargeView = ChargeView(context)
    private val pctText = makeText(context, 48f, Color.WHITE, true)
    private val wattText = makeText(context, 28f, Color.parseColor("#00E5A0"), true)
    private val timeText = makeText(context, 20f, Color.WHITE, false)
    private val infoText = makeText(context, 14f, Color.GRAY, false)

    private val tick = object : Runnable {
        override fun run() {
            update()
            postDelayed(this, 500)
        }
    }

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setBackgroundColor(Color.BLACK)
        val d = resources.displayMetrics.density
        setPadding((16 * d).toInt(), (48 * d).toInt(), (16 * d).toInt(), (48 * d).toInt())
        addView(chargeView, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        addView(pctText)
        addView(wattText)
        addView(timeText)
        addView(infoText)
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        removeCallbacks(tick)
        if (visibility == View.VISIBLE) post(tick)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    private fun update() {
        val r = if (demo) demoReading() else BatteryMonitor.read(context)
        chargeView.percent = r.pct
        chargeView.animating = r.charging
        val col = if (r.watts >= 18) 0xFF22D3FF.toInt() else 0xFF00E5A0.toInt()
        chargeView.color = col
        wattText.setTextColor(col)
        pctText.text = if (r.pct >= 99.995f) "100%" else String.format(Locale.US, "%.2f%%", r.pct)

        when {
            r.full -> {
                wattText.text = "Fully charged ✅"
                timeText.text = ""
            }
            !r.charging -> {
                wattText.text = "Charger nahi laga"
                timeText.text = ""
            }
            else -> {
                wattText.text = if (r.watts > 0.1) String.format(Locale.US, "⚡ %.1f W", r.watts) else "⚡ measuring…"
                timeText.text = if (r.remainMs > 0) "Full in ${fmt(r.remainMs)}" else "Time calculate ho raha hai…"
            }
        }
        val speed = when {
            !r.charging -> ""
            r.watts >= 15 -> "Fast charging"
            r.watts >= 5 -> "Charging"
            else -> "Slow charging"
        }
        infoText.text = listOf(
            speed,
            r.source,
            if (r.volts > 0) String.format(Locale.US, "%.2f V", r.volts) else ""
        ).filter { it.isNotEmpty() }.joinToString("  •  ")
    }

    private fun demoReading(): Reading {
        val t = System.currentTimeMillis() / 1000.0
        val pct = (40.0 + (t % 600.0) / 10.0).toFloat()
        return Reading(pct, 24.6 + sin(t) * 0.4, 4.3, 38 * 60_000L, true, false, "Demo")
    }

    private fun fmt(ms: Long): String {
        val m = ceil(ms / 60000.0).toLong()
        return if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m"
    }

    private fun makeText(ctx: Context, size: Float, color: Int, bold: Boolean) = TextView(ctx).apply {
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
        layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }
}
